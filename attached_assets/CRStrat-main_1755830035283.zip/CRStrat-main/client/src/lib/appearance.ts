export function setAccent(rgb: string) {
  document.documentElement.style.setProperty('--accent', rgb);
}
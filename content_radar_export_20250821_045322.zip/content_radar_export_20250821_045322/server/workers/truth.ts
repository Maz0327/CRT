// placeholder for deep jobs we'll add in A2 (text.deep, visual.*)
export const TruthJobs = {
  // enqueue(id, kind: 'text.deep' | 'visual.quick' | 'visual.deep') {}
};
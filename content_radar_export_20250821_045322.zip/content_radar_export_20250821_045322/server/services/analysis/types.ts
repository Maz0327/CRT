export interface RequestEvidence {
  text?: string;
  url?: string;
}
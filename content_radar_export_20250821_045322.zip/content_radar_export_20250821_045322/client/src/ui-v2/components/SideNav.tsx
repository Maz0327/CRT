export function SideNav() {
  return null; // Not used in current design
}
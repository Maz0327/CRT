export function PageHeader() {
  return null; // Not used in current design
}
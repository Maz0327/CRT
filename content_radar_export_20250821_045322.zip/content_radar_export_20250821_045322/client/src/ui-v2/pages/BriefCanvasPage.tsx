import { CanvasHost } from '../brief-canvas/CanvasHost';

export default function BriefCanvasPage() {
  return <CanvasHost />;
}
// Re-export everything from supabase-schema.ts for drizzle migrations
export * from './supabase-schema';